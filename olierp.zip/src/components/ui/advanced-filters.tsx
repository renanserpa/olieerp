"use client";

import React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

// Define Zod schema para validação do formulário de filtros avançados
const filterFormSchema = z.object({
  name: z.string().optional(),
  sku: z.string().optional(),
  description: z.string().optional(),
  document: z.string().optional(),
  email: z.string().optional(),
  city: z.string().optional(),
  is_active: z.string().optional(),
  status: z.string().optional(),
  created_after: z.string().optional(),
  created_before: z.string().optional(),
});

type FilterFormValues = z.infer<typeof filterFormSchema>;

export type FilterOption = {
  id: string;
  label: string;
  type: "text" | "select" | "date" | "boolean";
  options?: { value: string; label: string }[];
  placeholder?: string;
};

interface AdvancedFiltersProps {
  filterOptions: FilterOption[];
  onFilterChange: (filters: { [key: string]: string }) => void;
  onClearFilters?: () => void;
}

export function AdvancedFilters({ filterOptions, onFilterChange, onClearFilters }: AdvancedFiltersProps) {
  const form = useForm<FilterFormValues>({
    resolver: zodResolver(filterFormSchema),
    defaultValues: {},
  });

  const onSubmit = (data: FilterFormValues) => {
    // Filtrar apenas os campos que têm valores
    const activeFilters = Object.entries(data).reduce((acc, [key, value]) => {
      if (value && value.trim() !== "") {
        acc[key] = value;
      }
      return acc;
    }, {} as { [key: string]: string });

    onFilterChange(activeFilters);
    toast.success("Filtros aplicados com sucesso!");
  };

  const handleClearFilters = () => {
    form.reset();
    onFilterChange({});
    if (onClearFilters) {
      onClearFilters();
    }
    toast.info("Filtros limpos com sucesso!");
  };

  const renderField = (option: FilterOption) => {
    switch (option.type) {
      case "text":
        return (
          <FormField
            key={option.id}
            control={form.control}
            name={option.id as keyof FilterFormValues}
            render={({ field }) => (
              <FormItem>
                <FormLabel>{option.label}</FormLabel>
                <FormControl>
                  <Input 
                    placeholder={option.placeholder || `Digite ${option.label.toLowerCase()}`} 
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      case "select":
        return (
          <FormField
            key={option.id}
            control={form.control}
            name={option.id as keyof FilterFormValues}
            render={({ field }) => (
              <FormItem>
                <FormLabel>{option.label}</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder={`Selecione ${option.label.toLowerCase()}`} />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {option.options?.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      case "date":
        return (
          <FormField
            key={option.id}
            control={form.control}
            name={option.id as keyof FilterFormValues}
            render={({ field }) => (
              <FormItem>
                <FormLabel>{option.label}</FormLabel>
                <FormControl>
                  <Input 
                    type="date" 
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      case "boolean":
        return (
          <FormField
            key={option.id}
            control={form.control}
            name={option.id as keyof FilterFormValues}
            render={({ field }) => (
              <FormItem>
                <FormLabel>{option.label}</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder={`Selecione ${option.label.toLowerCase()}`} />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="true">Ativo</SelectItem>
                    <SelectItem value="false">Inativo</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-4 p-4 border rounded-lg bg-card">
      <h3 className="text-lg font-medium">Filtros Avançados</h3>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filterOptions.map(renderField)}
          </div>
          <div className="flex gap-2">
            <Button type="submit">Aplicar Filtros</Button>
            <Button type="button" variant="outline" onClick={handleClearFilters}>
              Limpar Filtros
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}

