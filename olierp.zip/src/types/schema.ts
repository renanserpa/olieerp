// Arquivo de tipos para alinhamento com o schema real do banco
// Este arquivo contém interfaces TypeScript que correspondem exatamente às tabelas do banco de dados

export interface Client {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  document: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  postal_code: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface Supplier {
  id: string;
  name: string;
  fantasy_name: string | null;
  cnpj: string | null;
  email: string | null;
  phone: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  postal_code: string | null;
  contact_name: string | null;
  contact_phone: string | null;
  contact_email: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface StockItem {
  id: string;
  name: string;
  sku: string | null;
  description: string | null;
  quantity: number;
  min_quantity: number;
  group_id: string | null;
  location_id: string | null;
  unit_of_measurement_id: string;
  is_active: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface StockGroup {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface Location {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface UnitOfMeasurement {
  id: string;
  name: string;
  symbol: string;
  description: string | null;
  created_at: string;
  updated_at: string | null;
}

export interface Component {
  id: string;
  name: string;
  code: string | null;
  description: string | null;
  price: number;
  category_id: string | null;
  unit_of_measurement_id: string;
  is_active: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface ComponentCategory {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface Supply {
  id: string;
  name: string;
  sku: string | null;
  description: string | null;
  quantity: number;
  min_quantity: number;
  unit_of_measurement_id: string;
  supplier_id: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface Product {
  id: string;
  name: string;
  sku: string | null;
  description: string | null;
  price: number;
  category_id: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface ProductCategory {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface ProductComponent {
  id: string;
  product_id: string;
  component_id: string;
  quantity: number;
  created_at: string;
  updated_at: string | null;
}

export interface Order {
  id: string;
  client_id: string;
  order_number: string;
  status: string;
  total_amount: number;
  order_date: string;
  delivery_date: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string | null;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  created_at: string;
  updated_at: string | null;
}

export interface ProductionOrder {
  id: string;
  order_id: string | null;
  status: string;
  start_date: string | null;
  end_date: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string | null;
}

export interface ProductionOrderItem {
  id: string;
  production_order_id: string;
  product_id: string;
  quantity: number;
  created_at: string;
  updated_at: string | null;
}

export interface PurchaseRequest {
  id: string;
  supplier_id: string;
  request_number: string;
  status: string;
  total_amount: number;
  request_date: string;
  delivery_date: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string | null;
}

export interface PurchaseRequestItem {
  id: string;
  purchase_request_id: string;
  supply_id: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  created_at: string;
  updated_at: string | null;
}

export interface StockMovement {
  id: string;
  stock_item_id: string;
  movement_type: string;
  quantity: number;
  reference_id: string | null;
  reference_type: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string | null;
}

export interface DeliveryRoute {
  id: string;
  route_name: string;
  driver_name: string | null;
  vehicle: string | null;
  status: string;
  start_date: string | null;
  end_date: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string | null;
}

export interface DeliveryRouteOrder {
  id: string;
  delivery_route_id: string;
  order_id: string;
  sequence: number;
  status: string;
  delivery_date: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string | null;
}
